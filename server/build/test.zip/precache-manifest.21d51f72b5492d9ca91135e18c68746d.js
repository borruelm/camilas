self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7521bc8fab0644b6905a127d6bab107d",
    "url": "./index.html"
  },
  {
    "revision": "78edaa28b10ee386cd7e",
    "url": "./static/css/2.0b828417.chunk.css"
  },
  {
    "revision": "ffc9e73c402715660207",
    "url": "./static/css/main.2cce8147.chunk.css"
  },
  {
    "revision": "78edaa28b10ee386cd7e",
    "url": "./static/js/2.07590c3e.chunk.js"
  },
  {
    "revision": "ffc9e73c402715660207",
    "url": "./static/js/main.25bdb525.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "1cedb6e919bfed6a2c1ec00b5d8ee620",
    "url": "./static/media/UploadIcon.1cedb6e9.svg"
  },
  {
    "revision": "aec35e2ee39de703572fc13409347c73",
    "url": "./static/media/camilasCartel.aec35e2e.png"
  },
  {
    "revision": "5f5e89c5078122b4365f68a7db8cd97c",
    "url": "./static/media/imgCar1.5f5e89c5.jpg"
  },
  {
    "revision": "d3ab6b413eefb4cfd36d9b2bec46f3d4",
    "url": "./static/media/imgCar2.d3ab6b41.jpg"
  },
  {
    "revision": "37bc23740a49dc302f7750d8be95fb64",
    "url": "./static/media/imgCar3.37bc2374.jpg"
  }
]);